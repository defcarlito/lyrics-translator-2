export default function WordCard() {
  return (
    <div className="bg-card p-4 shadow-md h-fit">
      <h1>word</h1>
      <p>description</p>
    </div>
  )
}