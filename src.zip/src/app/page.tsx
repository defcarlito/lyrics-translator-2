import Content from "@/components/content/Content.client"

export default function Home() {
  return (
    <div className="flex flex-col items-center w-screen my-8 gap-4">
      <Content />
    </div>
  )
}
