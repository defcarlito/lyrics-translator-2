import SongSearchBox from "@/components/content/client/SongSearchBox"

export default function Home() {

  return (
    <div className="flex items-center justify-center h-screen w-screen">
      <SongSearchBox />
    </div>
  )
}
