export type Setter<Type> = React.Dispatch<React.SetStateAction<Type>>
