import { NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  const body = await request.json()
  const word = body.word
  
  console.log(word)

  return NextResponse.json({
    word: "test",
  })
}
