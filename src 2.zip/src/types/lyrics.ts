export type Lyrics = {
  byLine: string[]
  byWord: string[]

}